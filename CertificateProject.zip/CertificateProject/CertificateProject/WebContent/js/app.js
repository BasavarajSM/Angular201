var m = angular.module('myapp', []);

m.controller('AddController', ['$scope', function($scope) {
	$scope.isFormSubmit = false;
	
	$scope.employees = [];
	$scope.add = function(emp) {
	
			if ($scope.addEmployeeForm.$valid) {
				$scope.employees.push(emp);
				$scope.emp = {};
				$scope.isFormSubmit = false;
			}
			else {
				$scope.isFormSubmit = true;
			}
			
		
		
	}
	$scope.isAssignFormSubmit = false;
	$scope.edit = function(emp) {
		$scope.e = emp;
	}
	
	$scope.assign = function() {
		if ($scope.assignForm.$valid) {
			$scope.e = {};
			$scope.isAssignFormSubmit = false;
		}
		else {
			$scope.isAssignFormSubmit = true;
		}
		
	}
}])

m.controller('AssignController', ['$scope', function($scope) {
	
}])